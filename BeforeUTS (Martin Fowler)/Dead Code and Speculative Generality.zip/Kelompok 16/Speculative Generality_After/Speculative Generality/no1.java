public class no1 {

    public static void main(String[] args) {
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        printEvenAndOddNumbers(numbers);
    }

    public static void printEvenAndOddNumbers(int[] numbers) {
        System.out.println("Even numbers:");
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 0) {
                System.out.println(numbers[i]);
            } else {
                System.out.println("Odd");
                System.out.println(numbers[i]);
            }
        }

        System.out.println("\nNumbers multiplied by 2:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i] * 2);
        }

        System.out.println("\nNumbers divided by 2:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i] / 2.0);
        }
    }

}