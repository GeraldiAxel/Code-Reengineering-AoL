package DeadCode;

import java.util.*;

public class DiscountCalculation {
	public double setFinalPrice(int priceBefore) {
		
		double finalPrice=0;
		
		finalPrice = priceBefore - (priceBefore*0.1);
		
		return finalPrice;
	}

}
