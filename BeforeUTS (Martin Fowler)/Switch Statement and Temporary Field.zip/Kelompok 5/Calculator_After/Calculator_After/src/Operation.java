public interface Operation {
    void perform();

    String pilihanOperasi(); 
}
