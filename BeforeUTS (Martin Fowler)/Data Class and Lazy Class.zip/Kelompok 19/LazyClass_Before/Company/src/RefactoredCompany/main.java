package RefactoredCompany;

public class main {
	public static void Main(String[] args) {
		
	}
}
