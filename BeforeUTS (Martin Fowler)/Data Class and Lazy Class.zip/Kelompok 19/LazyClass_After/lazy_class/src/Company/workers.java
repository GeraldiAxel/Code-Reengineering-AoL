package Company;

public class workers {
    private String name;
    private int salary;

    public workers(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void print_worker() {
        System.out.println(this.name + "'s salary is Rp." + this.salary);
    }
}