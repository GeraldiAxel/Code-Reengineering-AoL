package paralell_inheritance_hierarchies.before;

public interface AreaInterface {
	public float area();
}
