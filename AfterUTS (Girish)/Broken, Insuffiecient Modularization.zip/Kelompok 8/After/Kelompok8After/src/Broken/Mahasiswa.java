package Broken;

public class Mahasiswa {
    private DataMahasiswa data;

    public String getNIM() {
        return data.getNIM();
    }
}
