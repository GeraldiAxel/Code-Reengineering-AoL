public class DataMahasiswa {
	public String NIM;
	public String Email;
    public String NomorTelepon;
	//...
}