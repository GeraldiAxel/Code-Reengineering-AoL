public class Main {
    public static void main(String[] args) throws Exception {

        Employee employee1 = new Employee();
        employee1.setName("John");
        employee1.setGender("Male");
        employee1.setAge(26);
        employee1.setSalary(10000);
        employee1.salaryIncrease(100);
    
        employee1.display();
    }
}
