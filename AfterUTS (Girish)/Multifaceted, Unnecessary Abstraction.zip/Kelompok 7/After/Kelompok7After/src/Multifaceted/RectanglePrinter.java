package Multifaceted;

public class RectanglePrinter {
    private Rectangle rectangle;

    public RectanglePrinter(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public void print(String style) {
        style = style.toLowerCase();
        if (style.equals("full")) {
            for (int i = 0; i < rectangle.getHeight(); i++) {
                for (int j = 0; j < rectangle.getWidth(); j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        } else if (style.equals("border")) {
            for (int i = 0; i < rectangle.getHeight(); i++) {
                for (int j = 0; j < rectangle.getWidth(); j++) {
                    System.out.print(
                            j == 0 || j == rectangle.getWidth() - 1 ||
                            i == 0 || i == rectangle.getHeight() - 1 ? "*" : " ");
                }
                System.out.println();
            }
        } else {
            System.out.println("style not recognized");
        }
    }
}

