
public class Main {
	 public static void main(String[] args) {
		    EmailService emailService = new EmailService();
		    emailService.sendEmail("john.doe@example.com", "Hello", "This is a test email.");
		}
}
