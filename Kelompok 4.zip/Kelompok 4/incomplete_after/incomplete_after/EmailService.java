public class EmailService {
	private SmtpClient smtpClient;

    public EmailService(SmtpClient smtpClient) {
        this.smtpClient = smtpClient;
    }

    public void sendEmail(String to, String subject, String body) {
        smtpClient.send(to, subject, body);
    }
}
