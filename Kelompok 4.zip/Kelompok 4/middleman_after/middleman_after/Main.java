public class Main {

    public static void main(String[] args) {
        System.out.println("What weapon is the warrior using");

        Weapon weapon1 = new Weapon("Sword", "Longsword");
        Warrior warrior1 = new Warrior("Swordsman", weapon1);

        weapon1.weapontype();
    }

}